# Submitting AJAX Forms with jQuery

Code for the [scotch.io](http://scotch.io) tutorial: Submitting AJAX Forms with jQuery